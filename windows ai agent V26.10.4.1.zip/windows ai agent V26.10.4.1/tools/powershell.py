import subprocess
import re

TOOL_NAME = "powershell"

POWERSHELL_PATH = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

def run(command: str = "", as_admin: bool = False, **kwargs) -> str:
    """
    執行 PowerShell 指令（自動修復路徑非法字元與轉義問題）
    """
    if not command:
        return "【執行失敗】: AI 未提供必要的 'command' 參數。"

    # 1. 自動清理可能導致 Illegal characters in path 的雙重引號或換行
    command = command.strip().replace('\r', '').replace('\n', ' ')
    
    # 2. 強制 PowerShell 輸出 UTF-8
    utf8_prefix = "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
    full_command = f"{utf8_prefix} {command}"

    try:
        if as_admin:
            escaped_cmd = full_command.replace('"', '`"')
            ps_script = f'Start-Process "{POWERSHELL_PATH}" -ArgumentList "-NoProfile -Command \"{escaped_cmd}\"" -Verb RunAs -Wait'
            
            result = subprocess.run(
                [POWERSHELL_PATH, "-Command", ps_script],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30
            )
            stdout = result.stdout or ""
            stderr = result.stderr or ""

            if result.returncode == 0:
                return "【執行成功】: 已發送管理員權限提權請求，並成功執行完成。"
            else:
                return f"【提權執行失敗】:\n{stderr.strip()}"

        result = subprocess.run(
            [POWERSHELL_PATH, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", full_command],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15
        )

        stdout = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()

        if result.returncode == 0:
            return stdout if stdout else "【執行成功】: 指令已成功執行（無文字輸出）。"
        else:
            return f"【指令執行失敗】:\n標準錯誤輸出 (stderr):\n{stderr}"

    except subprocess.TimeoutExpired:
        return "【執行逾時】: 指令執行超過時間上限已被中斷。"
    except Exception as e:
        return f"【系統例外錯誤】: {str(e)}"