import requests

# 工具名稱，tools/__init__.py 會自動載入[cite: 1]
TOOL_NAME = "weather"

def run(location: str = "", **kwargs) -> str:
    """
    透過 wttr.in 免費服務查詢指定地區的天氣資訊（支援中文）。
    """
    if not location:
        return "【執行失敗】: AI 未提供必要的 'location' 參數。"

    # 清理輸入字串
    location_clean = location.strip().replace(" ", "+")

    # 取得結構化中文天氣文字 (包含天氣狀況、溫度、體感溫度、濕度、風速)
    url = f"https://wttr.in/{location_clean}?format=%l:+%C+%t+(體感+%f),+濕度+%h,+風速+%w&lang=zh-tw"

    headers = {
        "User-Agent": "curl/7.68.0"  # 模擬 curl 可取得乾淨的純文字回傳
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            result_text = response.text.strip()
            if "Unknown location" in result_text or "404" in result_text:
                return f"【查詢失敗】: 找不到地區 '{location}' 的天氣資料，請確認名稱是否正確。"
            return f"【天氣查詢結果】:\n{result_text}"
        else:
            return f"【查詢失敗】: 伺服器回傳 HTTP 狀態碼 {response.status_code}"

    except requests.TimeoutExpired:
        return "【執行逾時】: 天氣查詢請求超過時間上限。"
    except Exception as e:
        return f"【系統例外錯誤】: {str(e)}"