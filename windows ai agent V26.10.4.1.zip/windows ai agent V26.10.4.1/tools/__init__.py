import os
import importlib

TOOL_REGISTRY = {}

tools_dir = os.path.dirname(__file__)

for filename in os.listdir(tools_dir):
    if filename.endswith(".py") and not filename.startswith("__"):
        module_name = filename[:-3]
        module = importlib.import_module(f"tools.{module_name}")
        
        if hasattr(module, "TOOL_NAME") and hasattr(module, "run"):
            TOOL_REGISTRY[module.TOOL_NAME] = module.run
            print(f"[Loaded Tool]: {module.TOOL_NAME} (from tools/{filename})")