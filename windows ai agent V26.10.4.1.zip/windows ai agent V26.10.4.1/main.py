import json
import re
import requests
from tools import TOOL_REGISTRY

# 1. 讀取設定檔
with open("config.json", "r", encoding="utf-8") as f:
    CONFIG = json.load(f)

# 2. 讀取工具清單說明 (tools.txt)
with open("tools.txt", "r", encoding="utf-8") as f:
    TOOLS_PROMPT = f.read()

def call_llm(messages, json_mode=False):
    """底層 API 呼叫 (支援 Ollama 與 OpenAI)"""
    provider = CONFIG.get("provider", "ollama")

    if provider == "ollama":
        url = CONFIG["ollama"]["url"]
        payload = {
            "model": CONFIG["ollama"]["model"],
            "messages": messages,
            "stream": False,
            "options": {"temperature": 0.1}
        }
        if json_mode:
            payload["format"] = "json"
        
        try:
            res = requests.post(url, json=payload, timeout=60).json()
            content = res.get("message", {}).get("content", "")
            if not content:
                content = res.get("response", "")
            return content.strip()
        except Exception:
            return ""

    elif provider == "openai":
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {CONFIG['openai']['api_key']}"}
        payload = {
            "model": CONFIG["openai"]["model"],
            "messages": messages,
            "temperature": 0.1
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        try:
            res = requests.post(url, json=payload, headers=headers, timeout=60).json()
            return res["choices"][0]["message"]["content"].strip()
        except Exception:
            return ""

    return ""


def route_intent(user_input):
    """一次性對話：向 AI 詢問意圖與工具參數，並處理反斜線路徑轉義"""
    router_prompt = f"""你是一個高效能系統意圖分發路由器。請根據【可用工具清單】與【使用者需求】，決定最合適的工具與參數。

【可用工具清單】
{TOOLS_PROMPT}

【使用者需求】
{user_input}

【格式要求】
必須且只能輸出標準 JSON 物件，格式如下：
{{
  "thought": "分析使用者意圖",
  "tool": "powershell",
  "args": {{
    "command": "New-Item -Path '$env:USERPROFILE\\\\Desktop\\\\new.txt' -ItemType File -Force"
  }}
}}
注意：若為 powershell 工具，command 參數內的 Windows 路徑請一律用正斜線 (/) 或單引號，嚴禁使用帶有非法轉義字元的字串！如果工具是 chat，則 args 請留空字典 {{}}。
"""
    response_text = call_llm([{"role": "user", "content": router_prompt}], json_mode=True)
    
    if not response_text:
        return {"tool": "chat", "args": {}, "thought": "API 未回傳，降級為純聊天"}

    try:
        # 自動修復 LLM 因單反斜線導致的無效 JSON 字串
        cleaned_json = re.sub(r'(?<!\\)\\(?!["\\/bfnrtu])', r'\\\\', response_text)
        return json.loads(cleaned_json)
    except:
        match = re.search(r'\{.*\}', response_text, re.DOTALL)
        if match:
            try:
                cleaned_match = re.sub(r'(?<!\\)\\(?!["\\/bfnrtu])', r'\\\\', match.group(0))
                return json.loads(cleaned_match)
            except:
                pass
        return {"tool": "chat", "args": {}, "thought": "解析失敗，降級為純聊天"}


if __name__ == "__main__":
    # 人設定位：高效能 AI Agent，專注成果，拒絕冗詞贅字
    conversation_history = [
        {"role": "system", "content": "你是一個高效能 Windows AI Agent。你的任務是精準執行指令，並將系統資訊轉化為結構清晰、重點明確的結果摘要給使用者，不說客套話與廢話。"}
    ]

    print("==========================================")
    print(" Windows AI Router Agent 已啟動")
    print("==========================================")

    while True:
        try:
            # 輸入提示詞，保持循環自然順暢
            user_input = input("\n請輸入需求 (輸入 'exit' 離開): ").strip()
            if not user_input:
                continue
            if user_input.lower() == 'exit':
                print("系統已退出。")
                break

            # 1. 背景路由決策 (不輸出 Log 於主主面)
            decision = route_intent(user_input)
            selected_tool = decision.get("tool", "chat")
            tool_args = decision.get("args", {})

            # 2. 工具分流處理
            if selected_tool == "chat" or selected_tool not in TOOL_REGISTRY:
                conversation_history.append({"role": "user", "content": user_input})
                reply = call_llm(conversation_history)
                
                if not reply:
                    reply = "（系統未收到 AI 回覆，請確認模型狀態）"

                conversation_history.append({"role": "assistant", "content": reply})
                print(f"\nAI: {reply}")

            else:
                exec_func = TOOL_REGISTRY[selected_tool]
                
                try:
                    # 靜默執行工具
                    exec_result = exec_func(**tool_args)
                except Exception as e:
                    exec_result = f"工具執行發生例外錯誤: {str(e)}"

                # 3. 專屬 AI 摘要 Prompt：資料消化並答覆，不再將原始資料吐回畫面
                feedback_prompt = f"""你是一個高效能 AI Agent。請針對【使用者需求】，整理並回覆【系統實際執行結果】。

【回覆準則】：
1. 嚴禁重複貼上原始系統 Log、指令或裸資料。
2. 直接提供結構化摘要（重點條列或表格），講求精確、高效，去除客套用語。
3. 若失敗，直接指出關鍵原因與下一步建議。

使用者需求：{user_input}
系統實際執行結果：
{exec_result}
"""
                final_reply = call_llm([
                    {"role": "system", "content": "你是一個高效能 Windows AI Agent，專注於輸出結構化、精準的任務執行結果。"},
                    {"role": "user", "content": feedback_prompt}
                ])
                
                if not final_reply:
                    final_reply = "任務執行完畢，但未能取得系統摘要報告。"

                # 更新對話歷史
                conversation_history.append({"role": "user", "content": user_input})
                conversation_history.append({"role": "assistant", "content": final_reply})

                # 畫面上只輸出使用者輸入與這段 AI 的最終整理答覆
                print(f"\nAI: {final_reply}")

        except KeyboardInterrupt:
            print("\n系統已退出。")
            break
        except Exception as e:
            print(f"\n系統錯誤: {e}")